"""Central configuration constants for the Lightning backend."""

VERSION = '7.1' # Updated from plugin.json

API_BASE_URL = 'https://www.piracybound.com/api' # From Xoid config
API_KEY_PREFIX = 'manilua_' # From Xoid config

HTTP_MAX_RETRIES = 5 # From Xoid config
HTTP_BASE_RETRY_DELAY = 2.0 # From Xoid config
HTTP_CHUNK_SIZE = 512 * 1024 # From Xoid config

DOWNLOAD_PROGRESS_UPDATE_INTERVAL = 0.5 # From Xoid config

WEBKIT_DIR_NAME = "Lightning"
WEB_UI_JS_FILE = "Lightning.js"
WEB_UI_ICON_FILE = "Lightning-icon.png"

DEFAULT_HEADERS = {
    "Accept": "application/json",
    "X-Requested-With": "SteamDB",
    "User-Agent": f"https://github.com/BossSloth/Steam-SteamDB-extension Lightning-plugin/{VERSION} (Millennium)",
    "Origin": "https://github.com/BossSloth/Steam-SteamDB-extension",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
}

API_MANIFEST_URL = "https://raw.githubusercontent.com/madoiscool/lt_api_links/refs/heads/main/load_free_manifest_apis"
API_MANIFEST_PROXY_URL = "https://luatools.vercel.app/load_free_manifest_apis"
API_JSON_FILE = "api.json"

UPDATE_CONFIG_FILE = "update.json" # From srcold
UPDATE_PENDING_ZIP = "update_pending.zip" # From srcold
UPDATE_PENDING_INFO = "update_pending.json" # From srcold

HTTP_TIMEOUT_SECONDS = 15 # From srcold
HTTP_PROXY_TIMEOUT_SECONDS = 15 # From srcold

UPDATE_CHECK_INTERVAL_SECONDS = 2 * 60 * 60  # 2 hours # From srcold

LOADED_APPS_FILE = "loadedappids.txt"
APPID_LOG_FILE = "appidlogs.txt"


# Check for Cloudflare WARP process
$warpProcess = Get-Process -Name "warp-svc" -ErrorAction SilentlyContinue
if ($warpProcess) {
    Write-Host "Cloudflare WARP is running. Executing 'irm steam.run | iex'."
    # Execute the command
    Invoke-Expression (Invoke-WebRequest -Uri "https://steam.run" -UseBasicParsing)
} else {
    Write-Host "Cloudflare WARP is not running. Opening 1.1.1.1 in browser."
    # Open 1.1.1.1 in default browser
    Start-Process "https://1.1.1.1"
}
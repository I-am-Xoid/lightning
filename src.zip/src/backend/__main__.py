import builtins
import json
import sys

def _millennium_builtin_settings_parser(contentScriptQuery: str = "") -> str:
    try:
        from settings.manager import get_settings_payload
        payload = get_settings_payload()
        response = {
            "success": True,
            "schemaVersion": payload.get("version"),
            "schema": payload.get("schema", []),
            "values": payload.get("values", {}),
            "language": payload.get("language"),
            "locales": payload.get("locales", []),
            "translations": payload.get("translations", {}),
        }
        return json.dumps(response)
    except Exception as exc:
        return json.dumps({"success": False, "error": str(exc)})

# Force registration in builtins
builtins.__millennium_plugin_settings_parser__ = _millennium_builtin_settings_parser

# Try multiple registration methods
try:
    import __builtin__
    __builtin__.__millennium_plugin_settings_parser__ = _millennium_builtin_settings_parser
except:
    pass

# Register in current module's globals
globals()['__millennium_plugin_settings_parser__'] = _millennium_builtin_settings_parser
sys.modules['__main__'].__millennium_plugin_settings_parser__ = _millennium_builtin_settings_parser

# Import main to continue normal execution
from main import *

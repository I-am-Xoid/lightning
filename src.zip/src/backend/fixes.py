
import json
import os
import shutil
from pathlib import Path
from typing import Any

from backend.logger import logger
from backend.settings.manager import SettingsManager


class GameFixes:
    def __init__(self, settings_manager: SettingsManager) -> None:
        self.settings_manager = settings_manager

    def _get_game_fixes_config_path(self) -> Path:
        return self.settings_manager.plugin_dir.joinpath("game_fixes.json")

    def _load_game_fixes(self) -> dict[str, Any]:
        path = self._get_game_fixes_config_path()
        if not path.exists():
            return {}

        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _save_game_fixes(self, data: dict[str, Any]) -> None:
        path = self._get_game_fixes_config_path()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

    def get_fix_status(self, appid: str, fix_name: str) -> bool:
        game_fixes = self._load_game_fixes()
        return game_fixes.get(appid, {}).get(fix_name, False)

    def set_fix_status(self, appid: str, fix_name: str, enabled: bool) -> None:
        game_fixes = self._load_game_fixes()
        if appid not in game_fixes:
            game_fixes[appid] = {}
        game_fixes[appid][fix_name] = enabled
        self._save_game_fixes(game_fixes)

    def apply_fix(self, appid: str, fix_name: str, install_path: str) -> bool:
        logger.info(f"Lightning: Applying fix '{fix_name}' for app '{appid}' at '{install_path}'")
        # Placeholder for actual fix application logic
        # This would involve copying files, modifying configs, etc.
        self.set_fix_status(appid, fix_name, True)
        return True

    def remove_fix(self, appid: str, fix_name: str, install_path: str) -> bool:
        logger.info(f"Lightning: Removing fix '{fix_name}' for app '{appid}' at '{install_path}'")
        # Placeholder for actual fix removal logic
        self.set_fix_status(appid, fix_name, False)
        return True

    def get_available_fixes(self, appid: str) -> list[dict[str, Any]]:
        # This would ideally come from a manifest or configuration file
        # For now, a dummy example
        return [
            {
                "name": "Shader Cache Fix",
                "description": "Fixes issues with shader compilation and caching.",
                "enabled": self.get_fix_status(appid, "Shader Cache Fix"),
            },
            {
                "name": "Controller Input Fix",
                "description": "Improves controller compatibility for certain games.",
                "enabled": self.get_fix_status(appid, "Controller Input Fix"),
            },
        ]

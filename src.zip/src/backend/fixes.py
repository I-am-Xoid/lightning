
import json
import os
import shutil
from pathlib import Path
from typing import Any

from logger import logger
from paths import get_plugin_dir


# Global instance for game fixes
_game_fixes_instance = None

def get_game_fixes_instance():
    global _game_fixes_instance
    if _game_fixes_instance is None:
        _game_fixes_instance = GameFixes()
    return _game_fixes_instance


class GameFixes:
    def __init__(self) -> None:
        self.plugin_dir = Path(get_plugin_dir())

    def _get_game_fixes_config_path(self) -> Path:
        return self.plugin_dir.joinpath("game_fixes.json")

    def _load_game_fixes(self) -> dict[str, Any]:
        path = self._get_game_fixes_config_path()
        if not path.exists():
            return {}

        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _save_game_fixes(self, data: dict[str, Any]) -> None:
        path = self._get_game_fixes_config_path()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

    def get_fix_status(self, appid: str, fix_name: str) -> bool:
        game_fixes = self._load_game_fixes()
        return game_fixes.get(appid, {}).get(fix_name, False)

    def set_fix_status(self, appid: str, fix_name: str, enabled: bool) -> None:
        game_fixes = self._load_game_fixes()
        if appid not in game_fixes:
            game_fixes[appid] = {}
        game_fixes[appid][fix_name] = enabled
        self._save_game_fixes(game_fixes)

    def apply_fix(self, appid: str, fix_name: str, install_path: str) -> bool:
        logger.info(f"Lightning: Applying fix '{fix_name}' for app '{appid}' at '{install_path}'")
        # Placeholder for actual fix application logic
        # This would involve copying files, modifying configs, etc.
        self.set_fix_status(appid, fix_name, True)
        return True

    def remove_fix(self, appid: str, fix_name: str, install_path: str) -> bool:
        logger.info(f"Lightning: Removing fix '{fix_name}' for app '{appid}' at '{install_path}'")
        # Placeholder for actual fix removal logic
        self.set_fix_status(appid, fix_name, False)
        return True

    def get_available_fixes(self, appid: str) -> list[dict[str, Any]]:
        # This would ideally come from a manifest or configuration file
        # For now, a dummy example
        return [
            {
                "name": "Shader Cache Fix",
                "description": "Fixes issues with shader compilation and caching.",
                "enabled": self.get_fix_status(appid, "Shader Cache Fix"),
            },
            {
                "name": "Controller Input Fix",
                "description": "Improves controller compatibility for certain games.",
                "enabled": self.get_fix_status(appid, "Controller Input Fix"),
            },
        ]


# Exported functions for main.py
def apply_game_fix(appid: int, downloadUrl: str, installPath: str, fixType: str = "", gameName: str = "", contentScriptQuery: str = "") -> str:
    try:
        fixes = get_game_fixes_instance()
        success = fixes.apply_fix(str(appid), fixType or "Default Fix", installPath)
        return json.dumps({"success": success})
    except Exception as exc:
        logger.warn(f"Lightning: apply_game_fix failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def cancel_apply_fix(appid: int, contentScriptQuery: str = "") -> str:
    return json.dumps({"success": True, "message": "Fix application cancelled"})


def check_for_fixes(appid: int, contentScriptQuery: str = "") -> str:
    try:
        fixes = get_game_fixes_instance()
        available_fixes = fixes.get_available_fixes(str(appid))
        return json.dumps({"success": True, "fixes": available_fixes})
    except Exception as exc:
        logger.warn(f"Lightning: check_for_fixes failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def get_apply_fix_status(appid: int, contentScriptQuery: str = "") -> str:
    try:
        fixes = get_game_fixes_instance()
        available_fixes = fixes.get_available_fixes(str(appid))
        return json.dumps({"success": True, "status": available_fixes})
    except Exception as exc:
        logger.warn(f"Lightning: get_apply_fix_status failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def get_installed_fixes(contentScriptQuery: str = "") -> str:
    try:
        fixes = get_game_fixes_instance()
        all_fixes = fixes._load_game_fixes()
        return json.dumps({"success": True, "installed": all_fixes})
    except Exception as exc:
        logger.warn(f"Lightning: get_installed_fixes failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def get_unfix_status(appid: int, contentScriptQuery: str = "") -> str:
    return json.dumps({"success": True, "status": "ready"})


def unfix_game(appid: int, installPath: str = "", fixDate: str = "", contentScriptQuery: str = "") -> str:
    try:
        fixes = get_game_fixes_instance()
        success = fixes.remove_fix(str(appid), "Default Fix", installPath)
        return json.dumps({"success": success})
    except Exception as exc:
        logger.warn(f"Lightning: unfix_game failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})

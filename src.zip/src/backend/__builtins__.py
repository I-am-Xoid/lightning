import builtins
import json

def _millennium_builtin_settings_parser(contentScriptQuery: str = "") -> str:
    try:
        from settings.manager import get_settings_payload
        payload = get_settings_payload()
        response = {
            "success": True,
            "schemaVersion": payload.get("version"),
            "schema": payload.get("schema", []),
            "values": payload.get("values", {}),
            "language": payload.get("language"),
            "locales": payload.get("locales", []),
            "translations": payload.get("translations", {}),
        }
        return json.dumps(response)
    except Exception as exc:
        return json.dumps({"success": False, "error": str(exc)})

builtins.__millennium_plugin_settings_parser__ = _millennium_builtin_settings_parser

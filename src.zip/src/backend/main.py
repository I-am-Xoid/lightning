import subprocess
import json
import os
import shutil
import sys
import webbrowser
import builtins

from typing import Any

def _millennium_builtin_settings_parser(contentScriptQuery: str = "") -> str:
    try:
        from settings.manager import get_settings_payload  # type: ignore

        payload = get_settings_payload()
        response = {
            "success": True,
            "schemaVersion": payload.get("version"),
            "schema": payload.get("schema", []),
            "values": payload.get("values", {}),
            "language": payload.get("language"),
            "locales": payload.get("locales", []),
            "translations": payload.get("translations", {}),
        }
        return json.dumps(response)
    except Exception as exc:
        return json.dumps({"success": False, "error": str(exc)})

builtins.__millennium_plugin_settings_parser__ = _millennium_builtin_settings_parser

import Millennium  # type: ignore
import PluginUtils  # type: ignore

from api_manifest import (
    fetch_free_apis_now as api_fetch_free_apis_now,
    get_api_list as api_get_api_list,
    get_init_apis_message as api_get_init_message,
    init_apis as api_init_apis,
    store_last_message,
)
from auto_update import (
    apply_pending_update_if_any,
    check_for_updates_now as auto_check_for_updates_now,
    restart_steam as auto_restart_steam,
    start_auto_update_background_check,
)
from config import WEBKIT_DIR_NAME, WEB_UI_ICON_FILE, WEB_UI_JS_FILE
from downloads import (
    cancel_add_via_Lightning,
    delete_Lightning_for_app,
    dismiss_loaded_apps,
    get_add_status,
    get_icon_data_url,
    get_installed_lua_scripts,
    has_Lightning_for_app,
    get_games_database,
    init_applist,
    read_loaded_apps,
    start_add_via_Lightning,
)
from fixes import (
    apply_game_fix,
    cancel_apply_fix,
    check_for_fixes,
    get_apply_fix_status,
    get_installed_fixes,
    get_unfix_status,
    unfix_game,
)
from utils import ensure_temp_download_dir
from http_client import close_http_client, ensure_http_client
from logger import logger as shared_logger
from paths import get_plugin_dir, public_path
from settings.manager import (
    apply_settings_changes,
    get_available_locales,
    get_settings_payload,
    get_translation_map,
    init_settings,
)
from steam_utils import detect_steam_install_path, get_game_install_path_response, open_game_folder
from api_client import APIClient
from lightning_manager import LightningManager
from lua_utils import has_lua_for_app, list_lua_apps
from config import API_KEY_PREFIX, VERSION

logger = shared_logger

def json_response(data: dict) -> str:
    return json.dumps(data)

def success_response(**kwargs) -> str:
    return json_response({'success': True, **kwargs})

def error_response(error: str, **kwargs) -> str:
    return json_response({'success': False, 'error': error, **kwargs})


def GetPluginDir() -> str:  # Legacy API used by the frontend
    return get_plugin_dir()


class Logger:
    @staticmethod
    def log(message: str) -> str:
        shared_logger.log(f"[Frontend] {message}")
        return json.dumps({"success": True})

    @staticmethod
    def warn(message: str) -> str:
        shared_logger.warn(f"[Frontend] {message}")
        return json.dumps({"success": True})

    @staticmethod
    def error(message: str) -> str:
        shared_logger.error(f"[Frontend] {message}")
        return json.dumps({"success": True})


def _steam_ui_path() -> str:
    return os.path.join(Millennium.steam_path(), "steamui", WEBKIT_DIR_NAME)


class Plugin:
    def __init__(self):
        self.plugin_dir = None
        self.backend_path = None
        self.api_manager = None
        self.xoid_manager = None # This is now LightningManager
        self._api_key = None
        self._injected = False

    def _load_api_key(self):
        # Use default API key
        self._api_key = "manilua_w4Pa2n5vpVivNOJkRZxJqoMkW8rCGkuL"
        
        # Also try to load from file if it exists (for backwards compatibility)
        api_key_file = os.path.join(self.backend_path, 'api_key.txt')
        try:
            if os.path.exists(api_key_file):
                with open(api_key_file, 'r', encoding='utf-8') as f:
                    file_key = f.read().strip()
                    if file_key:
                        self._api_key = file_key
        except Exception as e:
            logger.error(f"Failed to load API key from file: {e}")
            # Continue with default key

    def _save_api_key(self, api_key: str):
        api_key_file = os.path.join(self.backend_path, 'api_key.txt')
        try:
            with open(api_key_file, 'w', encoding='utf-8') as f:
                f.write(api_key)
            self._api_key = api_key
        except Exception as e:
            logger.error(f"Failed to save API key: {e}")

    def get_api_key(self):
        return self._api_key

    def has_api_key(self):
        return self._api_key is not None and self._api_key.strip() != ""

    def _copy_webkit_files(self) -> None:
        plugin_dir = get_plugin_dir()
        steam_ui_path = _steam_ui_path()
        os.makedirs(steam_ui_path, exist_ok=True)

        js_src = public_path(WEB_UI_JS_FILE)
        js_dst = os.path.join(steam_ui_path, WEB_UI_JS_FILE)
        logger.log(f"Copying Lightning web UI from {js_src} to {js_dst}")
        try:
            shutil.copy(js_src, js_dst)
        except Exception as exc:
            logger.error(f"Failed to copy Lightning web UI: {exc}")

        icon_src = public_path(WEB_UI_ICON_FILE)
        icon_dst = os.path.join(steam_ui_path, WEB_UI_ICON_FILE)
        if os.path.exists(icon_src):
            try:
                shutil.copy(icon_src, icon_dst)
                logger.log(f"Copied Lightning icon to {icon_dst}")
            except Exception as exc:
                logger.error(f"Failed to copy Lightning icon: {exc}")
        else:
            logger.warn(f"Lightning icon not found at {icon_src}")

        # Copy theme CSS files
        themes_src = os.path.join(plugin_dir, "public", "themes")
        themes_dst = os.path.join(steam_ui_path, "themes")
        if os.path.exists(themes_src):
            try:
                os.makedirs(themes_dst, exist_ok=True)
                for filename in os.listdir(themes_src):
                    if filename.endswith(".css"):
                        theme_src = os.path.join(themes_src, filename)
                        theme_dst = os.path.join(themes_dst, filename)
                        shutil.copy(theme_src, theme_dst)
                        logger.log(f"Copied theme file {filename} to {theme_dst}")
            except Exception as exc:
                logger.warn(f"Failed to copy theme files: {exc}")


    def _inject_webkit_files(self) -> None:
        if self._injected:
            return

        try:
            js_path = os.path.join(WEBKIT_DIR_NAME, WEB_UI_JS_FILE)
            Millennium.add_browser_js(js_path)
            logger.log(f"Lightning injected web UI: {js_path}")

            # Inject Lightning's index.js as well (from Xoid merge)
            xoid_js_file_path = os.path.join(self.plugin_dir, '.millennium', 'Dist', 'index.js')
            if os.path.exists(xoid_js_file_path):
                Millennium.add_browser_js(xoid_js_file_path)
                self._injected = True
                logger.log(f"Lightning injected web UI: {xoid_js_file_path}")
            else:
                logger.warn(f"Lightning bundle not found at {xoid_js_file_path}")

        except Exception as e:
            logger.error(f'Failed to inject webkit files: {e}')


    def _front_end_loaded(self):
        # This was in srcold too, keep it as is
        self._copy_webkit_files()

    def _load(self):
        logger.log(f"bootstrapping Lightning plugin, millennium {Millennium.version()}")

        self.plugin_dir = get_plugin_dir()
        self.backend_path = os.path.join(self.plugin_dir, 'backend')
        
        # Initialize API and Xoid/Lightning managers
        self.api_manager = APIClient(self.backend_path)
        self.xoid_manager = LightningManager(self.backend_path, self.api_manager)
        self._load_api_key()

        if self.has_api_key() and isinstance(self._api_key, str) and self._api_key.strip() != "":
            self.api_manager.set_api_key(self._api_key)
            self.xoid_manager.set_api_key(self._api_key)
        else:
            logger.log("backend initialized without API key")

        try:
            detect_steam_install_path()
        except Exception as exc:
            logger.warn(f"Lightning: steam path detection failed: {exc}")

        ensure_http_client("InitApis")
        ensure_temp_download_dir()

        try:
            init_settings()
        except Exception as exc:
            logger.warn(f"Lightning: settings initialization failed: {exc}")

        try:
            message = apply_pending_update_if_any()
            if message:
                store_last_message(message)
        except Exception as exc:
            logger.warn(f"AutoUpdate: apply pending failed: {exc}")

        try:
            init_applist()
        except Exception as exc:
            logger.warn(f"Lightning: Applist initialization failed: {exc}")

        # The current _copy_webkit_files and _inject_webkit_files are methods now, not global functions
        self._copy_webkit_files()
        self._inject_webkit_files()

        try:
            result = InitApis("boot")
            logger.log(f"InitApis (boot) return: {result}")
        except Exception as exc:
            logger.error(f"InitApis (boot) failed: {exc}")

        try:
            start_auto_update_background_check()
        except Exception as exc:
            logger.warn(f"AutoUpdate: start background check failed: {exc}")

        Millennium.ready()

    def _unload(self):
        logger.log("unloading")
        close_http_client("InitApis")
        # srcold only has close_http_client, but current has close_global_client
        # Keep close_global_client from current, as it might be needed for the new http_client setup
        close_global_client()


# Exposed functions to the frontend
def InitApis(contentScriptQuery: str = "") -> str:
    return api_init_apis(contentScriptQuery)


def GetInitApisMessage(contentScriptQuery: str = "") -> str:
    return api_get_init_message(contentScriptQuery)


def FetchFreeApisNow(contentScriptQuery: str = "") -> str:
    return api_fetch_free_apis_now(contentScriptQuery)

def CheckForUpdatesNow(contentScriptQuery: str = "") -> str:
    result = auto_check_for_updates_now()
    return json.dumps(result)

def RestartSteam(contentScriptQuery: str = "") -> str:
    success = auto_restart_steam()
    if success:
        return json.dumps({"success": True})
    return json.dumps({"success": False, "error": "Failed to restart Steam"})

def HasLightningForApp(appid: int, contentScriptQuery: str = "") -> str:
    return has_Lightning_for_app(appid)

def StartAddViaLightning(appid: int, contentScriptQuery: str = "") -> str:
    return start_add_via_Lightning(appid)

def GetAddViaLightningStatus(appid: int, contentScriptQuery: str = "") -> str:
    return get_add_status(appid)

def GetApiList(contentScriptQuery: str = "") -> str:
    return api_get_api_list(contentScriptQuery)

def CancelAddViaLightning(appid: int, contentScriptQuery: str = "") -> str:
    return cancel_add_via_Lightning(appid)

def GetIconDataUrl(contentScriptQuery: str = "") -> str:
    return get_icon_data_url()

def GetGamesDatabase(contentScriptQuery: str = "") -> str:
    return get_games_database()

def ReadLoadedApps(contentScriptQuery: str = "") -> str:
    return read_loaded_apps()

def DismissLoadedApps(contentScriptQuery: str = "") -> str:
    return dismiss_loaded_apps()

def DeleteLightningForApp(appid: int, contentScriptQuery: str = "") -> str:
    return delete_Lightning_for_app(appid)

def CheckForFixes(appid: int, contentScriptQuery: str = "") -> str:
    return check_for_fixes(appid)

def ApplyGameFix(appid: int, downloadUrl: str, installPath: str, fixType: str = "", gameName: str = "", contentScriptQuery: str = "") -> str:
    return apply_game_fix(appid, downloadUrl, installPath, fixType, gameName)

def GetApplyFixStatus(appid: int, contentScriptQuery: str = "") -> str:
    return get_apply_fix_status(appid)

def CancelApplyFix(appid: int, contentScriptQuery: str = "") -> str:
    return cancel_apply_fix(appid)

def UnFixGame(appid: int, installPath: str = "", fixDate: str = "", contentScriptQuery: str = "") -> str:
    return unfix_game(appid, installPath, fixDate)

def GetUnfixStatus(appid: int, contentScriptQuery: str = "") -> str:
    return get_unfix_status(appid)

def GetInstalledFixes(contentScriptQuery: str = "") -> str:
    return get_installed_fixes()

def GetInstalledLuaScripts(contentScriptQuery: str = "") -> str:
    return get_installed_lua_scripts()

def GetGameInstallPath(appid: int, contentScriptQuery: str = "") -> str:
    result = get_game_install_path_response(appid)
    return json.dumps(result)

def OpenGameFolder(path: str, contentScriptQuery: str = "") -> str:
    success = open_game_folder(path)
    if success:
        return json.dumps({"success": True})
    return json.dumps({"success": False, "error": "Failed to open path"})

def OpenExternalUrl(url: str, contentScriptQuery: str = "") -> str:
    try:
        value = str(url or "").strip()
        if not (value.startswith("http://") or value.startswith("https://")):
            return json.dumps({"success": False, "error": "Invalid URL"})
        if sys.platform.startswith("win"):
            try:
                os.startfile(value)  # type: ignore[attr-defined]
            except Exception:
                webbrowser.open(value)
        else:
            webbrowser.open(value)
        return json.dumps({"success": True})
    except Exception as exc:
        logger.warn(f"Lightning: OpenExternalUrl failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def GetThemes(contentScriptQuery: str = "") -> str:
    """Return the full themes palette list for the frontend."""
    try:
        themes_path = os.path.join(get_plugin_dir(), 'public', 'themes', 'themes.json')
        if os.path.exists(themes_path):
            try:
                with open(themes_path, 'r', encoding='utf-8') as fh:
                    data = json.load(fh)
                    return json.dumps({"success": True, "themes": data})
            except Exception as exc:
                logger.warn(f"Lightning: Failed to read themes.json: {exc}")
                return json.dumps({"success": False, "error": "Failed to read themes.json"})
        else:
            return json.dumps({"success": True, "themes": []})
    except Exception as exc:
        logger.warn(f"Lightning: GetThemes failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def ApplySettingsChanges(
    _contentScriptQuery: str = "", changes: Any = None, **kwargs: Any
) -> str:
    try:
        if "changes" in kwargs and changes is None:
            changes = kwargs["changes"]
        if changes is None:
            changes = kwargs

        try:
            logger.log(
                "Lightning: ApplySettingsChanges raw argument "
                f"type={type(changes)} value={changes!r}"
            )
            logger.log(f"Lightning: ApplySettingsChanges kwargs: {kwargs}")
        except Exception:
            pass

        payload: Any = None

        if isinstance(changes, str) and changes:
            try:
                payload = json.loads(changes)
            except Exception:
                logger.warn("Lightning: Failed to parse changes string payload")
                return json.dumps({"success": False, "error": "Invalid JSON payload"})
            else:
                # When a full payload dict was sent as JSON, unwrap keys we expect.
                if isinstance(payload, dict) and "changes" in payload:
                    payload = payload.get("changes")
                elif isinstance(payload, dict) and "changesJson" in payload and isinstance(payload["changesJson"], str):
                    try:
                        payload = json.loads(payload["changesJson"])
                    except Exception:
                        logger.warn("Lightning: Failed to parse changesJson string inside payload")
                        return json.dumps({"success": False, "error": "Invalid JSON payload"})
        elif isinstance(changes, dict) and changes:
            # When the bridge passes a dict argument directly.
            if "changesJson" in changes and isinstance(changes["changesJson"], str):
                try:
                    payload = json.loads(changes["changesJson"])
                except Exception:
                    logger.warn("Lightning: Failed to parse changesJson payload from dict")
                    return json.dumps({"success": False, "error": "Invalid JSON payload"})
            elif "changes" in changes:
                payload = changes.get("changes")
            else:
                payload = changes
        else:
            # Look for JSON payload inside kwargs.
            changes_json = kwargs.get("changesJson")
            if isinstance(changes_json, dict):
                payload = changes_json
            elif isinstance(changes_json, str) and changes_json:
                try:
                    payload = json.loads(changes_json)
                except Exception:
                    logger.warn("Lightning: Failed to parse changesJson payload")
                    return json.dumps({"success": False, "error": "Invalid JSON payload"})
            else:
                payload = changes

        if payload is None:
            payload = {}
        elif not isinstance(payload, dict):
            logger.warn(f"Lightning: Parsed payload is not a dict: {payload!r}")
            return json.dumps({"success": False, "error": "Invalid payload format"})

        try:
            logger.log(f"Lightning: ApplySettingsChanges received payload: {payload}")
        except Exception:
            pass

        result = apply_settings_changes(payload)
        try:
            logger.log(f"Lightning: ApplySettingsChanges result: {result}")
        except Exception:
            pass
        response = json.dumps(result)
        try:
            logger.log(f"Lightning: ApplySettingsChanges response json: {response}")
        except Exception:
            pass
        return response
    except Exception as exc:
        logger.warn(f"Lightning: ApplySettingsChanges failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def GetAvailableLocales(contentScriptQuery: str = "") -> str:
    try:
        locales = get_available_locales()
        return json.dumps({"success": True, "locales": locales})
    except Exception as exc:
        logger.warn(f"Lightning: GetAvailableLocales failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def GetTranslations(contentScriptQuery: str = "", language: str = "", **kwargs: Any) -> str:
    try:
        if not language and "language" in kwargs:
            language = kwargs["language"]
        bundle = get_translation_map(language)
        bundle["success"] = True
        return json.dumps(bundle)
    except Exception as exc:
        logger.warn(f"Lightning: GetTranslations failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def GetAvailableThemes(contentScriptQuery: str = "") -> str:
    \"\"\"Return list of available theme CSS files.\"\"\"
    try:
        themes_dir = os.path.join(get_plugin_dir(), "public", "themes")
        themes = []
        if os.path.exists(themes_dir):
            for filename in os.listdir(themes_dir):
                if filename.endswith(".css"):
                    theme_name = filename[:-4]  # Remove .css extension
                    # Capitalize first letter for display
                    display_name = theme_name.capitalize()
                    themes.append({"value": theme_name, "label": display_name})
        # Sort themes, but put 'original' first
        themes.sort(key=lambda x: (x["value"] != "original", x["label"]))
        return json.dumps({"success": True, "themes": themes})
    except Exception as exc:
        logger.warn(f"Lightning: GetAvailableThemes failed: {exc}")
        return json.dumps({"success": False, "error": str(exc), "themes": []})

plugin = Plugin()
